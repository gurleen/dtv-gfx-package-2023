# pydak
Python Library for Daktronics AllSport 5000 Scoring Controllers

Based on the collaboration with  [JoshuaCarroll](https://github.com/JoshuaCarroll/scoredata)

This is being rolled into a single library for easy distribution.